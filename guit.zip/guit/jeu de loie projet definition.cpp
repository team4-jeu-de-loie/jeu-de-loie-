#include<iostream>
#include <cstdlib>
#include "surface.h"
#include "game.h"
#include "player.h"
#include "mouvment_pion.h"
#include "string.h"
using namespace sdt ;
//définitions des méthodes de la classe player
int player::claculescore(int i){
    score+=i;
}
void player::saisiename(){
    cout<<"donner le nom de joueur à ajouter"<<endl ;
    cin<<nom;
}
void player::saisiecolor():{
    cout<<"donner le coleur de joueur"<<endl ;
    cin<<color;
}
}
//définitions des méthodes de la classe game
void game::addplayer(player a){
    players=players+1 ;
    *players=a ;
};
void game::startgame(){
    cout<<"le jeu commence"<<endl ;
};
void game::gameover(){
    cout<<"le jeu est terminé"<<endl;
};
void game::succes(){
    cout<<"le joueur"<<nom<<"a gagné le tour"<<endl
}
//définition de la calsse mouvement_pion 
void player::lancement_de(player p){
    int somme=0 ;
    int difference= 0;
    anciennenumcase= numcase ;
    while (numde1<=0 || numde2<=0 ){
        numde1= rand(%6);
        numde2= rand(%6);
    }
    somme= numde1+numde2 ;
    numcase =anciennenumcase + somme ;
    if (numcase==0 && somme==9){
        cout<<"vous avez de la chance vous tomber sur un oie pour la première fois "<<endl;
        if (numde1==3 && numde2==6)|| (numde1==6 && numde2==3){
            numcase=26;
        }
        else if ((numde1==4 && numde2==5)||(numde1==5 && numde2==4))
        {
            numcase=53;
        }
    }
    else if ((numcase==18 ||numcase==27||numcase==45||numcase==54)&&(somme!=6){
        numcase+=somme;
    }
    else if (somme==6){
        numcase=12;
    }
    else if (numcase==19){
        cout<<"vous n'avez pas le droit de jouer"<<endl ;
    }
    else if (numcase==31 && p.numcase==31){
        numcase=p.anciennecase ;
    }
    else if (numcase==31 && p.numcase!=31){
        numcase=31;
        cout<<"aucun  joueur arrive au 31 vous devrez rester dans cette case"<<endl ;
    }
    else if (numcase==42) {
        numcase=30 ;
    }
    else if (numcase==52 && p.numcase==52){
        cout<<"félicitation vous pouvez continuer de jouer d'une façons ordinaire"<<endl ;
        numcase=numcase+somme ;
    }
    else if (numcase==58){
        cout<<"c'est la tete de la mort vous devrerz recommencer le jeu "<<endl ;
        numcase=0;
    }
    else if (numcase==p.numcase){
        numcase=p.anciennecase ;
    }
    else if (numcase==63){
        cout<<"félicitation vous avez gagné le jeu "
    }
    else if (numcase>63){
        difference=numcase-63 ;
        numcase=63-difference ;
    }
}
//définition de la méthode classe 
surface::plateau(double i , double j,int const h){
    ls=i ;
    hs= j ;
}

