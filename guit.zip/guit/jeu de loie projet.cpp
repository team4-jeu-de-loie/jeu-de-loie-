#include "string.h"
#ifndef SURFACE_H
#define SURFACE_H
class surface 
{
    private:
    int ls ;      // largeur de plateau
    int hs ;      // hauteur de plateau
    int const ncase = 63 ;      // nombre des cases

    public: 
    surface();     //conctrecteur surface 
    void plateu() ;
    ~surface();     //destrecteur surface
}
#endif
#ifndef GAME_H
#define GAME_H
class game
{
    public:
    game(int n): nbplayers(n), MAX(6){        //conctrecteur de game 
        players = new player[max];
        cout<<"concrtecteur de jeu de loie"
    }  
    void addplayer();          //ajouter des joueurs pour commencer le jeu
    void startgame();          // indique le début de jeu
    void gameover();           //indique la fin de jeu
    void sucess();
    ~game(){
        delete [] players ;
        cout<<"destruction de la classe game";          //distrecteur game 
    } 
    private:
    int const max;       //le nombre maximale des joueurs c'est 6
    int nbplayers ;
    player *players  ;    //pointeur qui pointe sur les élements de tableau qui sont des joueurs
}
#endif
#ifndef PLAYER_H
#define PLAYER _H
class player
{
    private:
    int score ;
    string name ;
    string color ;
    int numde1 ;              //numéro de dé lancé par le joueur lors de son tour 
    int numde2;
    int numcase ;          //numéro de case après le lancement de dé
    int anciennenumcase ;     
    public:
    player():name(""),color("") , score(0),numde1(0),numde2(0),numcase(0), anciennenumcase(0){            //constrecteur de nom de  joueur et de score
        cout<<"construction de joueur"<<endl ;
    }
    int claculescore(int);
    void saisiename();
    void saisiecolor () ;
    void  lancement_de(player p)
    ~player(){
        cout<<"destruction de joueur"<<endl    //destrecteur de joueur
    }      
#endif
}
