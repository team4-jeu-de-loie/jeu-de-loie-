#include<iostream>
#include"surface.h"
#include"game.h"
#include"palyer.h"
#include"mouvment_pion.h"
#include "string.h"
void main(){
    //préparation de l'inteface garphique 
    int const i=63 ;
    surface s ;
    int longueur ;
    int hauteur ;
    while (longueur<=0){
        cout<<"donner la languer de la surface"<<endl ;
        cin<<langueur ;
    }
     while (hauteur<=0){
        cout<<"donner la hauteur de la surface"<<endl ;
        cin<< hauteur ;
    }
    s.plateau(langueur, hauteur , 63);    
    //
    int n=0 ;
    while (n<0) || (n>6){
        cout<<"donner le nombre des joueur qui vont particper à cette jeu " ;
        cin<<n ;
    }
    game g(n);
    for(int i=0 i<n,i++){
        player a ;
        a.saisiename();
        a.saisiecolor();
        g.addplayer(a);
    }
    g.startgame();
    g[0].lancement_de(g[0]);
    int i=0
    cout<<"est ce que vous voulez sortir !"<<endl ;
    cin>>i ;
    while i= 0 {
        for(int i=1 i<n,i++){
        g[i].lancement_de(g[i-1]) ;
    }
}