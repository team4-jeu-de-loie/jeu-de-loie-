#include"game.h"
#include<iostream>
using namespace std ;
void game::addplayer(player &a){
    if (nbplayers==max){
        cout<<"le nombres des joueur maximale est atteint "<<endl ;
    }
    else {
        players[nbplayers++]=a;
        nbplayers=nbplayers+1 ;
    }
}
void game::startgame(){
    if(nbplayers>1){
        cout<<"le jeu commence"<<endl ;
    }
    else{
        cout<<"il faut au moins deux joueurs pour commencer!! "<<endl ;
    }
    
}
void game::gameover(){
    for(int i=0;i<nbplayers;i++){
        if(players[i].getnumcase()==63){
            cout<<"gameover!!";
            break;
        }
    }

     
    cout<<"le jeu n'est pas terminé!!"<<endl;
}
void game::sucess(){
    for (int i=0;i<nbplayers;i++){
        if (players[i].getnumcase()==63){
            cout<<"le joueur "<<players[i].getname()<<"est le gagnant" ;
            break;
        }
    }
    cout<<"pas de gagnant por le moment!!";        
 
   
}
void game::afficher_joueur(){
    for (int i=0;i<nbplayers;i++){
         players[i].afficher();
    }
}
int game::tour(){
    int tour=0;
    
    int i;
       do{
       i=0;                                          //s'arrete si un joueur arrive au case 63
       players[i].lancement_de(players[i]);
       for (i =1 ; i<nbplayers;i++){
         players[i].lancement_de(players[i-1]);
         
       }
       tour++;
       }
       while(players[i].getnumcase()!=63);
    
    return tour;                                    //nbr des tours total pour arriver au case 63
}