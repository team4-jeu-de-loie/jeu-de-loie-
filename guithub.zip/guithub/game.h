#include<iostream>
#include<string>
#include "player.h"
using namespace std ;
#ifndef GAME_H
#define GAME_H
class game
{
    public:
    game(int n): nbplayers(n), max(6){        //conctrecteur de game 
        players = new player[max];
        cout<<"concrtecteur de jeu de loie"<<endl ;
    }  
    void addplayer(player &a);          //ajouter les  joueurs pour commencer le tour
    void startgame();          // indique le début de jeu
    void gameover();           //indique la fin de jeu
    void sucess();
    void afficher_joueur();
    int tour();
    ~game(){
        delete [] players ;
        cout<<"destruction de la classe game";          //distrecteur game 
    } 
    private:
    int const max;       //le nombre maximale des joueurs c'est 6
    int nbplayers ;
    player *players  ;    //pointeur qui pointe sur les élements de tableau qui sont des joueurs
};
#endif