#include<iostream>
#include<string>
using namespace std ;
#ifndef PLAYER_H
#define PLAYER _H
class player
{
    private:
    int score ;
    string name ;
    string color ;
    int numde1 ;              //numéro de dé lancé par le joueur lors de son tour 
    int numde2;
    int numcase ;          //numéro de case après le lancement de dé
    int anciennenumcase ;     
    public:
    player():name(""),color("") , score(0),numde1(0),numde2(0),numcase(0), anciennenumcase(0){            //constrecteur de nom de  joueur et de score
        cout<<"construction de joueur"<<endl ;
    }
    void claculescore(int);
    void saisiename();
    void saisiecolor () ;
    void  lancement_de(player p) ;
    void afficher()  ;
    string getname(){
        return name;
    }
    int getnumcase(){
        return numcase;
    }
    ~player(){
        cout<<"destruction de joueur"<<endl  ; //destrecteur de joueur
    } 
};
#endif